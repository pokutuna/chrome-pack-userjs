var lib2 = require('../lib/lib2');
console.log('sample4-use-lib-ts');
new lib2.Lib2Sample('from sample4-use-lib-ts');
