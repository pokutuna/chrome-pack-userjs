var Lib1 = require('../lib/lib1').Lib1;
console.log('sample3-use-lib-js');
new Lib1(document.title);
