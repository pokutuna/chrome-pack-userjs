var Sample2 = (function () {
    function Sample2() {
    }
    Sample2.prototype.init = function () {
        console.log('sample2-ts');
    };
    return Sample2;
})();
(new Sample2()).init();
